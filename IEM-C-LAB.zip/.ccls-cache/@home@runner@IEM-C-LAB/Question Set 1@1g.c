//Write a c program to find area and perimeter of a rectangle.
#include <stdio.h>
int main()
{
  float l,b;
  printf("Enter length and breath of rectangle\n");
  scanf("%f", &l);
  scanf("%f", &b);
  float area=l*b;
  float perimeter=(2*(l+b));
  printf("Area: %f\n",area);
  printf("Perimeter: %f",perimeter);
}