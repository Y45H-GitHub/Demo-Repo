#include <stdio.h>

int main() {
    char name[50];
    int roll_no;
    char department[50];
    printf("Enter your name: ");
    scanf("%s", name);
    printf("Enter your roll number: ");
    scanf("%d", &roll_no);
    printf("Enter your department: ");
    scanf("%s", department);
    printf("Name: %s\nRoll No: %d\nDepartment: %s\n", name, roll_no, department);

    return 0;
}
