#include <stdio.h>
int main()
{
  int n1=2,n2=4,n3=6;
  printf("Product: %d",(n1*n2*n3));
}