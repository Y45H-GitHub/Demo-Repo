//Write a c program to find whether a number divisible by 100 or not.
#include <stdio.h>
int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);
    if (num % 100 == 0) {
        printf("%d is divisible by 100.\n", num);
    } else {
        printf("%d is not divisible by 100.\n", num);
    }
    return 0;
}
