//Write a c program to print area of a right-angled triangle (1/2 * base * height)
#include<stdio.h>  
int main()                      
{ 
  float b, h, area;  
  b = 5;  
  h= 8 ;  
  area = 0.5*( b * h);  
  printf("\n\n Area of Right Angle Triangle is : %f",area);  
}  