//Write a c program to swap numbers without using a third variable.
#include <stdio.h>
int main()
{
  int a=10,b=5,c;
  printf("BEFORE SWAPPING\n");
  printf("a= %d, b= %d",a,b);
  c=a+b;
  a=c-a;
  b=c-b;
  printf("\nAFTER SWAPPING\n");
  printf("a= %d, b= %d",a,b);
}