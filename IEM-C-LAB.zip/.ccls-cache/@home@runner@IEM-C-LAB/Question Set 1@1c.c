#include <stdio.h>
int main() 
{
    int n1;
    printf("Type 1st number: \n");
    scanf("%d", &n1);
  int n2;
    printf("Type 2nd number: \n");
    scanf("%d", &n2);
    int s=n1+n2;
    int d=(n1>n2)?n1-n2:n2-n1;
  printf("Sum of two numbers: %d\n",s);
  printf("Differece between two  numbers: %d",d);
}
