//Write a c program to accept the basic salary of an employee and calculate the gross salary.
/*
Assumptions made :
  1. If basic salary is less than or equal to 10000, then HRA is 20% of basic salary and DA is 80% of basic salary.
  2. If basic salary is between 10001 to 20000, then HRA is 25% of basic salary and DA is 90% of basic salary.
  3. If basic salary is greater than 20000, then HRA is 30% of basic salary and DA is 95% of basic salary.
*/
#include<stdio.h>
int main() {
    float basic_salary, gross_salary, HRA, DA;
    printf("Enter the basic salary of the employee: ");
    scanf("%f", &basic_salary);
    if(basic_salary <= 10000) {
        HRA = 0.2 * basic_salary;
        DA = 0.8 * basic_salary;
    } else if(basic_salary <= 20000) {
        HRA = 0.25 * basic_salary;
        DA = 0.9 * basic_salary;
    } else {
        HRA = 0.3 * basic_salary;
        DA = 0.95 * basic_salary;
      }
    gross_salary = basic_salary + HRA + DA;
    printf("Basic Salary: %.2f\n", basic_salary);
    printf("HRA: %.2f\n", HRA);
    printf("DA: %.2f\n", DA);
    printf("Gross Salary: %.2f\n", gross_salary);
    return 0;
}
