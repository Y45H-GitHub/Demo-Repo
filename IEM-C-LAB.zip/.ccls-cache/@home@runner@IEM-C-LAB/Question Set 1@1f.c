//Write a c program to find sum and average of 5 numbers.
#include <stdio.h>
int main()
{
  int n1=2,n2=4,n3=6,n4=18,n5=9;
  float sum=n1+n2+n3+n4+n5;
  float avg=sum/5;
  printf("Sum: %f\n", sum);
  printf("Average: %f", avg);
}