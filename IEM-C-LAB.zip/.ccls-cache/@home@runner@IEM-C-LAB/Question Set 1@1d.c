#include <stdio.h>
int main() {
    int num1 = 10, num2 = 5;
    int sum, diff;
    sum = num1 + num2;
    diff = num1 - num2;
    printf("Sum: %d\n", sum);
    printf("Difference: %d\n", diff);
    return 0;
}
