//Write a c program to print area of an equilateral triangle
#include<stdio.h>  
int main()   
{ 
  float a, area;  
  a= 5;  
  area = ( 1.73 * a*a) / 4 ;
  printf("\n\n Area of Equilateral Triangle is : %f",area);  
}