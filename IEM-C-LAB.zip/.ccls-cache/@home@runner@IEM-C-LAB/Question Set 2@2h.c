//Write a c program to accept the marks of a student and display the grade accordingly.
#include<stdio.h>
int main() {
    float marks;
    printf("Enter the marks of the student: ");
    scanf("%f", &marks);
    if(marks >= 90) {
        printf("Grade: A+\n");
    } else if(marks >= 80) {
        printf("Grade: A\n");
    } else if(marks >= 70) {
        printf("Grade: B+\n");
    } else if(marks >= 60) {
        printf("Grade: B\n");
    } else if(marks >= 50) {
        printf("Grade: C+\n");
    } else if(marks >= 40) {
        printf("Grade: C\n");
    } else {
        printf("Grade: F\n");
    }
    return 0;
}
