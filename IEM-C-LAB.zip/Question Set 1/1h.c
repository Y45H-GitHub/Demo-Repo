//Write a c program to print area and circumference of a circle.
#include<stdio.h>
int main() {
	float r, area;
	printf("\nEnter the radius of Circle : ");
	scanf("%f", &r);
	area = 3.14 * r * r;
	printf("\nArea of Circle : %f", area);
}