//Write a c program to evaluate value of Pi (π) up to 36 decimal places.
#include <stdio.h>
#include <math.h>
int main() {
    int i;
    double pi = 0.0;
    for (i = 0; i < 1000000; i++) {
        pi += (1.0/pow(16,i)) * ((4.0/(8*i+1)) - (2.0/(8*i+4)) - (1.0/(8*i+5)) - (1.0/(8*i+6)));
    }
    printf("%.36f\n", pi);
    return 0;
}
