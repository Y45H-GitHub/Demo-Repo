//Write a c program to swap two numbers using a third variable.
#include <stdio.h>
int main()
{
  int a=10,b=5,c;
  printf("BEFORE SWAPPING\n");
  printf("a= %d, b= %d",a,b);
  c=a;
  a=b;
  b=c;
  printf("\nAFTER SWAPPING\n");
  printf("a= %d, b= %d",a,b);
}